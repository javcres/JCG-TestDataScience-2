# jcg-testdatascience-2
Segundo ejercicio de la prueba de Data Science de Capgemini
